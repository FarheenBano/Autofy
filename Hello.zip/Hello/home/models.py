from django.db import models

# Create your models here.
class Contact(models.Model):
    name=models.CharField(max_length=122)
    email=models.CharField(max_length=122)
    phone=models.CharField(max_length=10)
    desc=models.TextField()
    date=models.DateField()

    def __str__(self):
        return self.name
    

# Create your models here.
class Image(models.Model):
    name=models.CharField(max_length=122)
    image=models.ImageField(upload_to="img",default="abc.jpg",null=True,blank=True)
    def __str__(self):
        return self.name

class uploads(models.Model):
    objects=None
    pic=models.ImageField(upload_to='pics')