from django.contrib import admin
from django.urls import path,include
from home import views

urlpatterns = [
   path("",views.index,name='home'),
   path(" ",views.userindex,name='user'),
   path("about",views.about,name='about'),
   path("contact",views.contact,name='contact'),
   path('signup',views.handelSignup,name='signup'),
   path("login",views.loginuser,name='login'),
   path('logout', views.logoutuser,name='logout'),

   path('upload', views.upload,name='upload'),
  
   path('translator', views.translator,name='translator'),
   path('translated', views.translated,name='translated'),
   path('img_translator', views.img_translator,name='img_translator'),
   path('img_translated', views.img_translated,name='img_translated'),

   # path('read', views.read,name='read'),
   ]

