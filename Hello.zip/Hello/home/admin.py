from django.contrib import admin
from home.models import Contact
# Register your models here.
admin.site.register(Contact)

from .models import Image
admin.site.register(Image)

from .models import uploads
admin.site.register(uploads)
