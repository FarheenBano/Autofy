import os
import glob
from pathlib import Path
from django.shortcuts import render,HttpResponse,redirect
from datetime import datetime
from home.models import Contact
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.contrib.auth import logout
from .utils import extract_text_from_image,text_to_speech
from .form import ImageForm
from .models import Image
from googletrans import Translator
# from playsound import playsound


# Create your views here.
gb=""
def index(request):
       return render(request,'index.html')


def userindex(request):
     if request.user.is_anonymous:
          return redirect('/')
     return render(request,'user.html')


def about(request):
    return render(request,'about.html')
    


def contact(request):
    if request.method == "POST":
       name=request.POST.get('name')
       email=request.POST.get('email')
       phone=request.POST.get('phone')
       desc=request.POST.get('desc')
       contact=Contact(name=name,email=email,phone=phone,desc=desc,date=datetime.today())
       contact.save()
       messages.success(request, 'Your data has been submitted Successfully.')
    return render(request,'contact.html')


def handelSignup(request):
    if request.method == "POST":
        #Get the post parameters
        username=request.POST['username']
        email=request.POST['email']
        password1=request.POST['password1']
        password=request.POST['password']

        #check for error inputs
        if len(username)>10:
            messages.error(request,"Username must be under 10 characters")
            return redirect('signup')
        if not username.isalnum():
            messages.error(request,"Username must be only numbers & letters")
            return redirect('signup')
        if password1 != password:
            messages.error(request,"Password do not match")
            return redirect('signup')
        # create the user
        myuser=User.objects.create_user(username,email,password1)
        myuser.save()
        messages.success(request,"Your account has been created successfully.")
        return redirect('home')
    return render(request,'signup.html')
   


def loginuser(request):
    if request.method == "POST":
        #Get the post parameters
        username=request.POST['username']
        password=request.POST['password']

        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('user')
           
        else:
            messages.success(request,"Invalid credentials, Please try again")
    return render(request,'login.html')
   


def logoutuser(request):
    logout(request)
    return redirect('/')



def upload(request):


    if request.method == "POST":
        form=ImageForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            obj=form.instance
            return render(request,"upload.html",{"obj":obj})

    else:
        form=ImageForm()
        text_data=''
        date_info=''
        fn=''
        r=[]
        s=[]
        print("\n\n_____________________________________________________\n")
        print("__________THIS IS THE NEW OUTPUT__________")
        path=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/media/img/"
        # path1=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/static/"


        # abc=os.listdir(path1)
        # print("abc--",abc)
        # print("path",path1)
        # print("abc--list",abc)
        # for i in abc:
        #     s.append(i)
        #     s.remove(i)
        #     print("abc--",s) 
        # r=s[-1:]
        # print("last upload-----------",r)   
        

        for filename in os.listdir(path):
            fn=os.path.join(path, filename)
            
            text_data=extract_text_from_image(fn)
            print("\nextracted text \n"+text_data)
            audio=text_to_speech(text_data)
            audio.save('static/speech1.mp3')
           
            # field_name = 'name'
            # obj = Image.objects.first()
            # field_object = Image._meta.get_field(field_name)
            # global field_value
            # field_value = field_object.value_from_object(obj)
            # aud=audio.save('static/audio/'+field_value+'.mp3')
            # print('audio-----------,',aud)
            # print("-------field value",field_value)
            # print("-------field value",type(field_value))
            # print("-------field value",str(field_value))
            
        
        # abc=os.listdir(path1)
        # print("*********",abc)

        
       

            

        a=[]
        b=[]
        img=Image.objects.all()
        for i in img:
            
            a.append(i)
              
        b=a[-1:]

       
        data={}
        data["imageText"]=text_data
        data["dateInfo"]=date_info

        posts = Image.objects.all()
        posts.delete()
       
        path=path+"*"
        list_of_f=glob.glob(path)
        print("list of farheen",list_of_f)
        
        

        for i in list_of_f:
            os.remove(i)
        
        # path1=path1+"*"
        # list_of=glob.glob(path1)
        # print("list of far",list_of)
        
       
        return render(request,"upload.html",{'b':b,'text_data':text_data,'form':form})


def translator(request):
   
    return render(request,'translator.html')
    

def translated(request):
    text=request.GET.get('text')
    lang=request.GET.get('lang')
    print('text:',text,'lang',lang)

    #connect the translator
    translator=Translator()
    #dtect Lang
    dt=translator.detect(text)
    dt2=dt.lang
    #translate the lang
    translated=translator.translate(text, lang)
    tr=translated.text
    audio=text_to_speech(tr)
    audio.save('static/speech4.mp3')
    return render(request,'translated.html',{'translated':tr,'u_lang':dt2,'t_lang':lang})

def img_translator(request):
    
    if request.method == "POST":
        form=ImageForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            obj=form.instance
            return render(request,"img_translator.html",{"obj":obj})

    else:
        form=ImageForm()
        text_data=''
        tr=''
        date_info=''
        fn=''
        lang=''
        r=''
        s=[]
        print("\n\n_____________________________________________________\n")
        print("__________THIS IS THE NEW OUTPUT__________")
        path=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/media/img/"
        for filename in os.listdir(path):
            fn=os.path.join(path, filename)
            
            text_data=text_data+extract_text_from_image(fn)
            
            print("\nextracted text \n"+text_data)
           

           
           

            

        a=[]
        b=[]
        img=Image.objects.all()
        for i in img:
            
            a.append(i)
              
        b=a[-1:]

       
        data={}
        data["imageText"]=text_data
        data["dateInfo"]=date_info

        posts = Image.objects.all()
        posts.delete()
       
        path=path+"*"
        list_of_f=glob.glob(path)
        print("list of farheen",list_of_f)
        
        

        for i in list_of_f:
            os.remove(i)
        
        
        
       
        return render(request,"img_translator.html",{'b':b,'text_data':text_data,'tr':tr,'form':form})

       
    # return render(request,'img_translator.html')
    
def img_translated(request):
    
    text=request.GET.get('text')
    lang=request.GET.get('lang')
    print('text:',text,'lang',lang)

    #connect the translator
    translator=Translator()
    #dtect Lang
    dt=translator.detect(text)
    dt2=dt.lang
    #translate the lang
    translated=translator.translate(text, lang)
    tr=translated.text
    audio=text_to_speech(tr)
    audio.save('static/speech3.mp3')
    return render(request,'img_translated.html',{'translated':tr,'u_lang':dt2,'t_lang':lang})    
   
   

